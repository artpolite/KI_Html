# KI-Assistenz-PC Hardwarestand (Stand: 2025-05-24)

| Komponente                            | Anzahl | Beschreibung                              |
|---------------------------------------|--------|--------------------------------------------|
| THERMALTAKE CTE C750 TG ARGB          | 1      | Gehäuse, Snow White                        |
| BE QUIET! Pure Power 12 M 1000W       | 1      | Netzteil, ATX 3.0                         |
| MSI MAG X670E TOMAHAWK WIFI           | 1      | Mainboard, AM5                            |
| AMD Ryzen 9 9950X                     | 1      | 16C/32T, 4.3-5.7 GHz                      |
| PATRIOT Viper VENOM DIMM Kit 64GB     | 2      | DDR5-6400, insgesamt 128GB                |
| WD_BLACK SN850X NVMe SSD 2TB          | 2      | M.2 SSD                                   |
| SAPPHIRE Nitro+ Radeon RX 7900 XTX    | 1      | 24GB GDDR6                                |
| THERMALTAKE CT140 ARGB Sync White     | 2      | Gehäuselüfter, 140mm, 2er Pack            |
| Raspberry Pi 5 (8GB) + Hailo 26 TOPS  | 1      | Firewall & KI-Beschleunigung              |